var currentWord = document.getElementById("currentWord");
currentWord.style.userSelect = "auto";
currentWord.style.pointerEvents = "auto";